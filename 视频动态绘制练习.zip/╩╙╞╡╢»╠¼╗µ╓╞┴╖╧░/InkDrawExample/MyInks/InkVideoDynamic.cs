﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Input.StylusPlugIns;
using System.Windows.Media;

namespace InkDrawExample.MyInks
{
    class InkVideoDynamic: DynamicAgent
    {
        public string inkText { private set; get; }
        public InkVideoStroke InkStroke { private set; get; }
        private Point previousPoint;
        private MediaPlayer p1;

        public void CreateNewStroke(InkCanvasStrokeCollectedEventArgs e)
        {
            InkStroke = new InkVideoStroke(this, e.Stroke.StylusPoints);//获取InkCanvas中的触点集合，并传给静态绘制方法
        }
        //设置播放器
        public static MediaPlayer CreateVideoPlayer(string uriString)
        {
            MediaPlayer p = new MediaPlayer();//初始化一个播放器p
            p.Open(new Uri(uriString, UriKind.Relative));//打开相对路径视频文件
            p.IsMuted = true;//设置静音
            p.MediaEnded += (s, e) => { p.Position = TimeSpan.Zero; };//从0开始播放
            p.Play();//播放文件
            return p;//返回p
        }

        public void Draw(Point first, MediaPlayer player, DrawingContext dc, StylusPointCollection points)
        {
            Point pt = (Point)points.Last();//获得终止点
            Vector v = Point.Subtract(pt, first);//获得向量
            if (double.IsNegativeInfinity(first.X)) return;//如果是负数则返回
            if (v.Length > 6)//向量长大于6
            {
                Rect rect = new Rect(first, v);//由起始点和向量构造矩形，画的时候呈现矩形
                dc.DrawVideo(player, rect);//使用DrawingContext中DrawView方法，按矩形画视频
            }
        }

        protected override void OnStylusDown(RawStylusInput rawStylusInput)//触笔按下时
        {
            base.OnStylusDown(rawStylusInput);//调用基类OnStylusDown
            previousPoint = (Point)rawStylusInput.GetStylusPoints().First();//得到鼠标按下的第一个点
            inkText = @"Video\Video2.wmv";//获得选择文件的相对路径
            p1 = CreateVideoPlayer(inkText);//给pl配置播放器
        }

        protected override void OnStylusUp(RawStylusInput rawStylusInput)//触笔松开
        {
            p1.Stop();
            p1.Close();//清除图像，等待就绪状态
            base.OnStylusUp(rawStylusInput);//调用基类OnStylusUp方法
        }


        protected override void OnDraw(DrawingContext drawingContext, StylusPointCollection stylusPoints, Geometry geometry, Brush fillBrush)
        {
            this.Draw(previousPoint, p1, drawingContext, stylusPoints);//调用自定义Draw方法，传入起点，播放器，绘图对象，触点集
        }
    }
}
