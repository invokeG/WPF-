﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Input.StylusPlugIns;
using System.Windows.Media;

namespace InkDrawExample.MyInks
{
    class MyInkCanvas : InkCanvas
    {
        public string selectShape;
        private InkVideoDynamic ink = new InkVideoDynamic();
        public MyInkCanvas()
        {
            DrawingAttributes inkDa = new DrawingAttributes
            {
                Color = Colors.Red,
                Height = 10,
                Width = 10,
                StylusTip = StylusTip.Rectangle
            };
            this.DefaultDrawingAttributes = inkDa;
            this.DynamicRenderer = ink;//将自定义的动态绘制对象分配给InkCanvas的DynamicRenderer属性
            this.EditingMode = InkCanvasEditingMode.Ink;
        }
        protected override void OnStrokeCollected(InkCanvasStrokeCollectedEventArgs e)
        {
            switch (selectShape)
            {
                case "球形":
                    this.Strokes.Remove(e.Stroke);
                    InkEllipseStroke stroke1 = new InkEllipseStroke(e.Stroke.StylusPoints);
                    this.Strokes.Add(stroke1);
                    break;
                case "矩形":
                    this.Strokes.Remove(e.Stroke);
                    InkRectangleStroke stroke2 = new InkRectangleStroke(e.Stroke.StylusPoints);
                    this.Strokes.Add(stroke2);
                    break;
                case "视频":
                    this.Strokes.Remove(e.Stroke);//移除已添加到InkCanvas中的原始笔画（动态绘制时的）
                    ink.CreateNewStroke(e);//创建自定义笔画
                    this.Strokes.Add(ink.InkStroke);//将自定义笔画添加到当前绘板的Strokes
                    break;
            }
        }
        public void setDyanmic(DynamicRenderer d1)
        {
            this.DynamicRenderer = d1;
        }
    }
}
