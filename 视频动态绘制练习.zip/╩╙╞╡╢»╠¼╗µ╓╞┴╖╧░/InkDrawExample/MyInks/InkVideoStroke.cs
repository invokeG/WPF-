﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Input.StylusPlugIns;
using System.Windows.Media;

namespace InkDrawExample.MyInks
{
    class InkVideoStroke: Stroke
    {
        private InkVideoDynamic ink;
        private string inkText;
        public InkVideoStroke(InkVideoDynamic ink, StylusPointCollection stylusPoints)
            : base(stylusPoints)//基类构造函数
        {
            this.ink = ink;//从动态绘制类中获得ink，赋值给本类的ink
            this.inkText = @"Video\Video2.wmv";//获取视频文件相对路径
        }

        protected override void DrawCore(DrawingContext drawingContext, DrawingAttributes drawingAttributes)
        {
            MediaPlayer mp = InkVideoDynamic.CreateVideoPlayer(inkText);//调用InkVideo中CreateVideoPlayer方法创建一个视频播放器mp
            Point pt1 = (Point)StylusPoints.First();//得到绘制的第一个点，与动态绘制不同
            ink.Draw(pt1, mp, drawingContext, StylusPoints);//调用Draw方法进行绘制，传入起点，播放器，绘图对象，触点集
        }
    }
}

